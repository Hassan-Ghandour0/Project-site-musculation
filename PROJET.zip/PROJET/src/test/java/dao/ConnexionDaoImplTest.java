package dao;

import junia.devweb.gymdatabase.dao.ConnexionDao;
import junia.devweb.gymdatabase.dao.impl.ConnexionDaoImpl;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ConnexionDaoImplTest {

    @Test
    public void testGetPassword() {
        ConnexionDao connexionDao = new ConnexionDaoImpl();
        String nicknameToTest = "clem";
        String motDePasse = connexionDao.getPassword(nicknameToTest);
        assertNotNull(motDePasse,"Le mot de passe ne doit pas être nul");
        System.out.println("Mot de passe pour le nickname '" + nicknameToTest + "': " + motDePasse);
    }
}

