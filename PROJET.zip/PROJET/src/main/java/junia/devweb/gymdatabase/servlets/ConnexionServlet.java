package junia.devweb.gymdatabase.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import junia.devweb.gymdatabase.services.ConnexionService;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

@WebServlet("/connexion")
public class ConnexionServlet extends GenericServlet {
    private static final Logger logger = LogManager.getLogger(ConnexionServlet.class);
    private final ConnexionService connexionService = new ConnexionService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JakartaServletWebApplication application = createApplication(req.getServletContext());
        IWebExchange webExchange = application.buildExchange(req , resp);
        WebContext context = new WebContext(webExchange);

        TemplateEngine templateEngine = createTemplateEngine(application);
        templateEngine.process("connexion", context, resp.getWriter());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String user = req.getParameter("user");
        String passwordInput = req.getParameter("Mdp");

        if (connexionService.authenticateUser(user, passwordInput)) {
            req.getSession().setAttribute("User", user);
            req.setAttribute("User", user);

            JakartaServletWebApplication application = createApplication(req.getServletContext());
            IWebExchange webExchange = application.buildExchange(req, resp);
            WebContext context = new WebContext(webExchange);

            TemplateEngine templateEngine = createTemplateEngine(application);
            templateEngine.process("index", context, resp.getWriter());

            logger.info("Connexion réussie pour l'utilisateur: {}", user);
        } else {
            String errorMessage = "Nom d'utilisateur ou mot de passe incorrect";
            req.setAttribute("erreurMsg1", errorMessage);

            JakartaServletWebApplication application = createApplication(req.getServletContext());
            IWebExchange webExchange = application.buildExchange(req, resp);
            WebContext context = new WebContext(webExchange);

            TemplateEngine templateEngine = createTemplateEngine(application);
            templateEngine.process("connexion", context, resp.getWriter());

            logger.warn("Échec de connexion pour l'utilisateur: {}", user);
        }
    }
}
