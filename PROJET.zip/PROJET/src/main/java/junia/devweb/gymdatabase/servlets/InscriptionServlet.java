package junia.devweb.gymdatabase.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import junia.devweb.gymdatabase.services.InscriptionService;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;

@WebServlet("/inscription")
public class InscriptionServlet extends GenericServlet {

    final InscriptionService inscriptionService = new InscriptionService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JakartaServletWebApplication application = createApplication(req.getServletContext());
        IWebExchange webExchange = application.buildExchange(req , resp);
        WebContext context = new WebContext(webExchange);

        TemplateEngine templateEngine = createTemplateEngine(application);
        templateEngine.process("inscription", context, resp.getWriter());
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String newUser = req.getParameter("newUser");
        String prenom = req.getParameter("Prenom");
        String nom = req.getParameter("Nom");
        String email = req.getParameter("Email");
        String newMdp = req.getParameter("newMdp");
        String confirmmdp = req.getParameter("confirmMdp");

        boolean InscriptionValide = inscriptionService.registerUser(newUser, prenom, nom, email, newMdp, confirmmdp);

        if (InscriptionValide) {
            resp.sendRedirect("connexion");
        } else {
            String erreurMsg2 = inscriptionService.checkRegistrationErrors(newUser, email, newMdp, confirmmdp);
            req.setAttribute("erreurMsg2", erreurMsg2);

            JakartaServletWebApplication application = createApplication(req.getServletContext());
            IWebExchange webExchange = application.buildExchange(req, resp);
            WebContext context = new WebContext(webExchange);

            TemplateEngine templateEngine = createTemplateEngine(application);
            templateEngine.process("inscription", context, resp.getWriter());
        }
    }
}
