package junia.devweb.gymdatabase.services;

import junia.devweb.gymdatabase.dao.InscriptionDao;
import junia.devweb.gymdatabase.dao.impl.InscriptionDaoImpl;

public class InscriptionService {
    private final InscriptionDao inscriptionDao = new InscriptionDaoImpl();

    public boolean registerUser(String newUser, String prenom, String nom, String email, String newMdp, String confirmMdp) {
        return inscriptionDao.Inscription(newUser, prenom, nom, email, newMdp, confirmMdp);
    }

    public String checkRegistrationErrors(String newUser, String email, String newMdp, String confirmMdp) {
        if (inscriptionDao.PseudoExiste(newUser.trim()) > 0) {
            return "Le pseudo existe déjà";
        }
        if (!inscriptionDao.EmailValid(email)) {
            return "L'Email n'est pas conforme";
        }
        if (!inscriptionDao.MdpValide(newMdp)) {
            return "Le mot de passe n'est pas conforme";
        }
        if (!inscriptionDao.MdpEqual(newMdp, confirmMdp)) {
            return "Veuillez confirmer le mot de passe";
        }
        return null;
    }
}
