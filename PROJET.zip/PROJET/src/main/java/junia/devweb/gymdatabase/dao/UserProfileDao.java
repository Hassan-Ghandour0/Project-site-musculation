package junia.devweb.gymdatabase.dao;

import java.util.Map;

public interface UserProfileDao {
    Map<String, Object> getUserById(int userId);

    void updatePassword(String user, String newPassword);

    String getNom(String User);

    String getPrenom(String User);

    String getEmail(String User);

    String getDate(String User);

    String getRole(String User);
}
