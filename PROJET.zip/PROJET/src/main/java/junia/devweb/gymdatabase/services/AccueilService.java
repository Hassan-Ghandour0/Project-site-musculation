package junia.devweb.gymdatabase.services;

import jakarta.servlet.http.HttpServletRequest;
import org.thymeleaf.context.WebContext;
import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;

public class AccueilService {
    private final ListeDao listeDao = new ListeDaoImpl();

    public void processAccueilContext(HttpServletRequest req, WebContext context) {
        String user = retrieveUser(req);
        String gestionAttribute = (listeDao.VerifAdmin(user) == 1) ? "Gestion Users" : "";

        context.setVariable("User", user);
        req.setAttribute("gestion", gestionAttribute);
    }

    private String retrieveUser(HttpServletRequest req) {
        String user = (String) req.getAttribute("User");
        if (user == null) {
            user = (String) req.getSession().getAttribute("User");
        }
        return user;
    }
}
