package junia.devweb.gymdatabase.services;

import junia.devweb.gymdatabase.dao.ConnexionDao;
import junia.devweb.gymdatabase.dao.impl.ConnexionDaoImpl;

public class ConnexionService {
    private final ConnexionDao connexionDao = new ConnexionDaoImpl();

    public boolean authenticateUser(String user, String password) {
        String storedPassword = connexionDao.getPassword(user);
        return storedPassword != null && storedPassword.equals(password);
    }
}
