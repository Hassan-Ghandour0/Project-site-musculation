package junia.devweb.gymdatabase.dao;

import junia.devweb.javacinee.entities.Film;

import java.util.List;

public interface ListeDao {

	 String getDescription(Integer id);
	 String getNom(Integer id);


	/*public Film addFilm(Film film);*/
}
