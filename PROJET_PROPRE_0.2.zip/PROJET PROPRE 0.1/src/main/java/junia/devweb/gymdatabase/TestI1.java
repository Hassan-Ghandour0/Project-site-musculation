package junia.devweb.gymdatabase;

import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;
import org.junit.jupiter.api.Test;

public class TestI1 {
    public static void main(String[] args) {
        ListeDao listeDao = new ListeDaoImpl();
        String description = listeDao.getDescription(1);
        String nom = listeDao.getNom(1);

        System.out.println(nom + description);
    }

}
