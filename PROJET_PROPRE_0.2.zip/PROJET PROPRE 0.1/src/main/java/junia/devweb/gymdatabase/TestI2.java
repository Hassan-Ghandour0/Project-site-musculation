package junia.devweb.gymdatabase;

import junia.devweb.gymdatabase.dao.ConnexionDao;
import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.impl.ConnexionDaoImpl;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;

public class TestI2 {
    public static void main(String[] args) {
        ConnexionDao ConnnexionDao = new ConnexionDaoImpl();
        String description = ConnnexionDao.getPassword("clem");

        System.out.println(description);
    }

}
