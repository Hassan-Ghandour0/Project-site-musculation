function deleteUser(userId) {
    if (confirm("Supprimer cet utilisateur ?")) {
        fetch('/gestion', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'userId=' + userId,
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erreur de suppresion');
                }
                location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
}