package junia.devweb.gymdatabase.dao;

public interface ListeDao {

	String getDescription(Integer id);
	String getNom(Integer id);

	int getMaxID();

	String getImageURL(Integer id);

	int getRechercheNombre(String recherche);

	String getRechercheNom(String recherche, int number);

	String getRechercheDescription(String recherche, int number);

	String getRechercheURL(String recherche, int number);

	int VerifAdmin(String User);

	void addExercice(String nomExo, String description);

	void switchFavoris(String nomExo, String Username);

	boolean isExerciceInFavorites(String nomExo, String Username);
}
