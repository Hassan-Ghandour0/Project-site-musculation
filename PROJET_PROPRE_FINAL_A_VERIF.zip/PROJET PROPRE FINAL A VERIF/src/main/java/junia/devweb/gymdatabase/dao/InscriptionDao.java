package junia.devweb.gymdatabase.dao;

public interface InscriptionDao {
    int PseudoExiste(String pseudo);


    boolean EmailValid(String prenom);

    boolean Inscription(String pseudo, String prenom, String nom, String email, String mdp, String confirmmdp);

    boolean MdpValide(String password);

    boolean MdpEqual(String mdp, String ConfirmMdp);
}