package junia.devweb.gymdatabase.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.UserProfileDao;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;
import junia.devweb.gymdatabase.dao.impl.UserProfileProfileDaoImpl;
import org.thymeleaf.TemplateEngine;

import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import static junia.devweb.gymdatabase.dao.impl.DataSourceProvider.dataSource;

@WebServlet("/user")
public class UserProfileServlet extends GenericServlet {
    private UserProfileDao userProfileDao = new UserProfileProfileDaoImpl(dataSource);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        JakartaServletWebApplication application = createApplication(req.getServletContext());

        IWebExchange webExchange = application.buildExchange(req, resp);
        String user = (String) req.getSession().getAttribute("User");
        WebContext context = new WebContext(webExchange);
        if(user== null) {
            resp.sendRedirect("connexion");
        }
        String nom = userProfileDao.getNom(user);
        context.setVariable("User",user);
        context.setVariable("nickname", user);
        context.setVariable("nom", nom);
        context.setVariable("prenom", userProfileDao.getPrenom(user));
        context.setVariable("email", userProfileDao.getEmail(user));
        context.setVariable("date_inscription", userProfileDao.getDate(user));
        context.setVariable("role", userProfileDao.getRole(user));
        ListeDao ListeDao = new ListeDaoImpl();
        if(ListeDao.VerifAdmin(user) == 1) {
            context.setVariable("gestion","Gestion Users");
        }else{
            context.setVariable("gestion","");
        }

        TemplateEngine templateEngine = createTemplateEngine(application);

        // Utiliser un StringWriter pour stocker le contenu généré par Thymeleaf
        StringWriter thymeleafOutput = new StringWriter();
        templateEngine.process("Profil", context, thymeleafOutput);

        // Ajouter le contenu généré par Thymeleaf au contenu manuel
        StringBuilder content = new StringBuilder(thymeleafOutput.toString());

        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println(thymeleafOutput.toString());
        out.close();
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String currentPassword = req.getParameter("currentPassword");
        String newPassword = req.getParameter("newPassword");
        Integer userIdObject = (Integer) req.getSession().getAttribute("userId");
        resp.setContentType("text/html");

        try (PrintWriter out = resp.getWriter()) {
            if (userIdObject != null) {
                int userId = userIdObject.intValue();
                String User = (String) req.getSession().getAttribute("User");
                Map<String, Object> user = userProfileDao.getUserById(userId);

                if (user != null) {
                    String storedPassword = (String) user.get("mot_de_passe");

                    if (currentPassword.equals(storedPassword)) {

                        userProfileDao.updatePassword(User, newPassword);
                        out.println("Mot de passe changé avec succès !");
                    } else {

                        out.println("Échec du changement de mot de passe. Veuillez vérifier votre mot de passe actuel.");
                    }
                }
            }
        }JakartaServletWebApplication application = createApplication(req.getServletContext());
        IWebExchange webExchange = application.buildExchange(req, resp);
        WebContext context = new WebContext(webExchange);

        TemplateEngine templateEngine = createTemplateEngine(application);
        templateEngine.process("Profil", context, resp.getWriter());
    }
}
