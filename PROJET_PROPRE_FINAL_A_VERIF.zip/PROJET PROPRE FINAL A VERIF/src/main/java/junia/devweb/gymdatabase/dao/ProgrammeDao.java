package junia.devweb.gymdatabase.dao;

public interface ProgrammeDao {

    String getProgrammeDescription(Integer id);

    String getProgrammeNom(Integer id);

    String getExoProgrammeNom(int programme, int number);

    String getExoProgrammeDescription(String recherche, int number);

    String getExoProgrammeURL(int programme, int number);

    int getExoProgrammeNombre(int programme);
}
