package junia.devweb.gymdatabase.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;

import java.io.IOException;

@WebServlet("/toggleFavorite")
public class ToggleFavoriteServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String nomExo = req.getParameter("username");
        String username = (String) req.getSession().getAttribute("User");

        final ListeDao ListeDao = new ListeDaoImpl();

        // Utilisez la méthode switchFavoris pour ajouter ou supprimer des favoris
        ListeDao.switchFavoris(nomExo, username);

        // Répondre avec succès
        resp.getWriter().write("Toggle favorite success for exercise: " + nomExo + ", user: " + username);
        resp.setStatus(HttpServletResponse.SC_OK);
    }
}
