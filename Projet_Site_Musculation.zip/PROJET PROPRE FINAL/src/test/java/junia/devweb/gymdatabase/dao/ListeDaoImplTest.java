package junia.devweb.gymdatabase.dao;

import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;

public class ListeDaoImplTest {

    @Test
    public void testGetDescription() {
        ListeDao listeDao = new ListeDaoImpl();

        // Remplacez l'ID par celui que vous souhaitez tester
        Integer idExercice = 1;

        // Appel de la méthode getDescription avec l'ID spécifié
        String descriptionExo = listeDao.getDescription(idExercice);

        // Vérifier si la description n'est pas nulle
        assertNotNull(descriptionExo, "La description ne devrait pas être nulle.");

        // Afficher la description
        System.out.println("Description de l'exercice avec l'ID " + idExercice + ": " + descriptionExo);
    }

    @Test
    public void testGetNom() {
        ListeDao listeDao = new ListeDaoImpl();

        // Remplacez l'ID par celui que vous souhaitez tester
        Integer idExercice = 1;

        // Appel de la méthode getNom avec l'ID spécifié
        String nomExo = listeDao.getNom(idExercice);

        // Vérifier si le nom n'est pas nul
        assertNotNull(nomExo, "Le nom ne devrait pas être nul.");

        // Afficher le nom
        System.out.println("Nom de l'exercice avec l'ID " + idExercice + ": " + nomExo);
    }

    @Test
    public void testGetImageUrl() {
        ListeDao listeDao = new ListeDaoImpl();

        // Remplacez l'ID par celui que vous souhaitez tester
        Integer idExercice = 1;

        // Appel de la méthode getDescription avec l'ID spécifié
        String ImageExo = listeDao.getImageURL(idExercice);

        // Vérifier si la description n'est pas nulle
        assertNotNull(ImageExo, "L'image ne devrait pas être nulle.");

        // Afficher la description
        System.out.println("Image de l'exercice avec l'ID " + idExercice + ": " + ImageExo);
    }
    @Test
    public void testGetMaxID(){
        // Given
        ListeDao listeDao = new ListeDaoImpl();
        // When
        int maxID=listeDao.getMaxID();
        // Then
        assertThat(listeDao.getNom(maxID+1)).isNull();
    }

    @Test
    public void testAddExercice() {
        // Given
        ListeDao listeDao = new ListeDaoImpl();
        String nomExo = "ExerciceTest";
        String descriptionExo = "Description de l'exercice de test.";

        // When
        listeDao.addExercice(nomExo, descriptionExo);

        int idexercice = listeDao.getMaxID();

        // Then
        assertEquals(listeDao.getNom(idexercice),nomExo,"Le nom est pas bon");
        assertEquals(listeDao.getDescription(idexercice),descriptionExo,"La description est pas bonne");
    }
    @Test
    public void testVerifAdmin() {
        // Given
        ListeDao listeDao = new ListeDaoImpl();
        String userName = "Kowaxis";

        // When
        int result = listeDao.VerifAdmin(userName);

        // Then
        assertThat(result).isEqualTo(1); // Assuming there is exactly one administrator with the given username
    }
    @Test
    public void testGetRechercheNombre() {
        // Given
        ListeDao listeDao = new ListeDaoImpl();
        String recherche = "épaule";

        // When
        int result = listeDao.getRechercheNombre(recherche);

        // Then
        assertThat(result).isGreaterThanOrEqualTo(0);
        System.out.println("Le nombre qui correspond à votre recherche est : "+result);
    }
    @Test
    public void testGetRechercheNom() {
        // Given
        ListeDao listeDao = new ListeDaoImpl();
        String recherche = "épaule";
        int Number = 1;

        // When
        String result = listeDao.getRechercheNom(recherche, Number);

        // Then
        assertThat(result).isNotNull();
        System.out.println("Voici votre résultat : "+result);
    }
    @Test
    public void testGetRechercheDescription() {
        // Given
        ListeDao listeDao = new ListeDaoImpl();
        String recherche = "épaule";
        int Number = 1;

        // When
        String result = listeDao.getRechercheDescription(recherche, Number);

        // Then
        assertThat(result).isNotNull();
        System.out.println("Voici votre résultat : "+result);
    }
    @Test
    public void testGetRechercheURL() {
        // Given
        ListeDao listeDao = new ListeDaoImpl();
        String recherche = "épaule";
        int rowNumber = 1;

        // When
        String result = listeDao.getRechercheURL(recherche, rowNumber);

        // Then
        assertThat(result).isNotNull();
        System.out.println("Voici votre résultat : "+result);
    }
}


