package junia.devweb.gymdatabase.dao;

import junia.devweb.gymdatabase.dao.impl.InscriptionDaoImpl;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class InscriptionDaoImplTest {

    @Test
    public void testInscription() {
        InscriptionDao inscriptionDao = new InscriptionDaoImpl();

        // Remplacez les valeurs par celles que vous souhaitez tester
        String pseudo = "T1";
        String prenom = "Tyler";
        String nom = "One";
        String email = "aad@fgdf";
        String mdp = "Password123$";
        String confirmmdp = "Password123$";

        // Vérifier que le pseudo n'existe pas déjà
        assertFalse(inscriptionDao.PseudoExiste(pseudo)>0, "Le pseudo existe déjà.");

        // test pour la validation de l'email
        assertTrue(inscriptionDao.EmailValid(email), "L'email n'est pas conforme.");

        // test pour la validation du mdp
        assertTrue(inscriptionDao.MdpValide(mdp),"le mot de passe n'est pas conforme");

        // test pour confirmer le mot de passe
        assertTrue(inscriptionDao.MdpEqual(mdp,confirmmdp),"Veuillez confirmer le mot de passe");

        // Appel de la méthode Inscription avec les valeurs spécifiées
        boolean inscriptionValide = inscriptionDao.Inscription(pseudo, prenom, nom, email, mdp, confirmmdp);

        // Vérifier si l'inscription est réussie
        assertTrue(inscriptionValide, "L'inscription devrait être réussie.");
    }
}

