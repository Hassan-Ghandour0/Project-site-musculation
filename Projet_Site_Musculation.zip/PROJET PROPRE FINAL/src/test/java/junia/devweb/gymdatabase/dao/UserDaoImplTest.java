package junia.devweb.gymdatabase.dao;

import junia.devweb.gymdatabase.dao.impl.UserDaoImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

public class UserDaoImplTest {

    @Mock
    private DataSource mockDataSource;

    private UserDaoImpl userDao;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        userDao = new UserDaoImpl(mockDataSource);
    }

    @Test
    void testGetAllUsers() throws SQLException {
        // Mock
        when(mockDataSource.getConnection()).thenReturn(mock(Connection.class));
        when(mockDataSource.getConnection().prepareStatement(anyString())).thenReturn(mock(PreparedStatement.class));
        when(mockDataSource.getConnection().prepareStatement(anyString()).executeQuery()).thenReturn(mock(ResultSet.class));

        List<Map<String, Object>> userList = userDao.getAllUsers();
        // Assert
        assertEquals(0, userList.size()); // Modify this based on your actual data
    }

    @Test
    void testDeleteUser() throws SQLException {
        // Mock
        when(mockDataSource.getConnection()).thenReturn(mock(Connection.class));
        when(mockDataSource.getConnection().prepareStatement(anyString())).thenReturn(mock(PreparedStatement.class));

        when(mockDataSource.getConnection().prepareStatement(anyString()).executeUpdate()).thenReturn(1);

        boolean isDeleted = userDao.deleteUser(1);

        assertTrue(isDeleted);
    }

    @Test
    void testUpdateUserRole() throws SQLException {
        // Mock
        when(mockDataSource.getConnection()).thenReturn(mock(Connection.class));
        when(mockDataSource.getConnection().prepareStatement(anyString())).thenReturn(mock(PreparedStatement.class));

        when(mockDataSource.getConnection().prepareStatement(anyString()).executeUpdate()).thenReturn(1);

        boolean isUpdated = userDao.updateUserRole(1, "newRole");

        assertTrue(isUpdated);
    }
}

