package junia.devweb.gymdatabase.dao.service;

import de.mkammerer.argon2.Argon2;
import de.mkammerer.argon2.Argon2Factory;
import junia.devweb.gymdatabase.dao.ConnexionDao;
import junia.devweb.gymdatabase.dao.impl.ConnexionDaoImpl;


public class ConnexionService {
    private final ConnexionDao connexionDao = new ConnexionDaoImpl();
    private final Argon2 argon2 = Argon2Factory.create();

    public boolean authenticateUser(String user, String password) {
        String storedPassword = connexionDao.getPassword(user);

        // Comparez le mot de passe haché stocké avec le mot de passe haché entré
        return argon2.verify(storedPassword, password);
    }
}

