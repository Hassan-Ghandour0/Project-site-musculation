package junia.devweb.gymdatabase.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;
import junia.devweb.gymdatabase.dao.impl.UserDaoImpl;
import junia.devweb.gymdatabase.services.UserService;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static junia.devweb.gymdatabase.dao.impl.DataSourceProvider.dataSource;

@WebServlet("/gestion")
public class ListeUserServlet extends GenericServlet {

    private final UserService userService;

    public ListeUserServlet() {
        this.userService = new UserService(new UserDaoImpl(dataSource));
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JakartaServletWebApplication application = createApplication(req.getServletContext());

        IWebExchange webExchange = application.buildExchange(req, resp);
        String User = (String) req.getSession().getAttribute("User");
        WebContext context = new WebContext(webExchange);
        context.setVariable("User", User);
        if(User== null) {
            resp.sendRedirect("connexion");
        }
        ListeDao ListeDao = new ListeDaoImpl();
        if(ListeDao.VerifAdmin(User) != 1){
            resp.sendRedirect("accueil");
        }

        List<Map<String, Object>> userList = userService.getAllUsers(); //récupérer la liste des utilisateurs
        context.setVariable("gestion", userList);

        TemplateEngine templateEngine = createTemplateEngine(application);
        templateEngine.process("gestion", context, resp.getWriter());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String userIdParam = req.getParameter("userId");
        String User = (String) req.getSession().getAttribute("User");
        if (userIdParam != null) {
            try {
                int userId = Integer.parseInt(userIdParam);
                boolean deleted = userService.deleteUser(userId,User);

                if (deleted) {
                    resp.setStatus(HttpServletResponse.SC_OK);
                } else {
                    resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                }
            } catch (NumberFormatException e) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            }
        } else {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }
    }
}