package junia.devweb.gymdatabase.dao.impl;

import junia.devweb.gymdatabase.dao.UserDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

public class UserDaoImpl implements UserDao {

    private final DataSource dataSource;

    public UserDaoImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    private Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    @Override
    public List<Map<String, Object>> getAllUsers() {
        List<Map<String, Object>> userList = new ArrayList<>();
        String sql = "SELECT * FROM `utilisateur`";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                Map<String, Object> user = new HashMap<>();
                user.put("id", resultSet.getInt("id"));
                user.put("nickname", resultSet.getString("nickname"));
                user.put("nom", resultSet.getString("nom"));
                user.put("prenom", resultSet.getString("prenom"));
                user.put("email", resultSet.getString("email"));
                user.put("mot_de_passe", resultSet.getString("mot_de_passe"));
                user.put("date_inscription", resultSet.getString("date_inscription"));
                user.put("role", resultSet.getString("role"));
                userList.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userList;
    }

    @Override
    public boolean deleteUser(int userId,String username) {
        String sql = "DELETE FROM `utilisateur` WHERE id = ? AND Nickname != ?";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, userId);
            preparedStatement.setString(2, username);
            int rowsDeleted = preparedStatement.executeUpdate();

            return rowsDeleted > 0;
        } catch (SQLException e) {
            throw new RuntimeException("err", e);
        }
    }

    @Override
    public boolean deleteUser(int userId) {
        String sql = "DELETE FROM `utilisateur` WHERE id = ? AND Nickname != ?";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, userId);
            int rowsDeleted = preparedStatement.executeUpdate();

            return rowsDeleted > 0;
        } catch (SQLException e) {
            throw new RuntimeException("err", e);
        }
    }

    @Override
    public boolean updateUserRole(int userId, String newRole) {
        String sql = "UPDATE `utilisateur` SET role = ? WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, newRole);
            preparedStatement.setInt(2, userId);

            int rowsUpdated = preparedStatement.executeUpdate();

            return rowsUpdated > 0;
        } catch (SQLException e) {
            // Log the exception or throw a custom exception
            throw new RuntimeException("Error updating user role in the database", e);
        }
    }
}