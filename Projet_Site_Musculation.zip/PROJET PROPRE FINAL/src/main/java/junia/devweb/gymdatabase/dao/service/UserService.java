package junia.devweb.gymdatabase.services;

import junia.devweb.gymdatabase.dao.UserDao;

import java.util.List;
import java.util.Map;

public class UserService {

    private final UserDao userDao;

    public UserService(UserDao userDao) {
        this.userDao = userDao;
    }

    public List<Map<String, Object>> getAllUsers() {
        return userDao.getAllUsers();
    }

    public boolean deleteUser(int userId, String username) {
        return userDao.deleteUser(userId,username);
    }
}