package junia.devweb.gymdatabase.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import junia.devweb.gymdatabase.dao.ConnexionDao;
import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.ProgrammeDao;
import junia.devweb.gymdatabase.dao.impl.ConnexionDaoImpl;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;
import junia.devweb.gymdatabase.dao.impl.ProgrammeDaoImpl;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;


@WebServlet("/programme")
public class ProgrammeServlet extends GenericServlet {
    final ConnexionDao connexionDao = new ConnexionDaoImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        JakartaServletWebApplication application = createApplication(req.getServletContext()); //recuperer le html
        IWebExchange webExchange = application.buildExchange(req, resp);
        String User = (String) req.getSession().getAttribute("User");
        WebContext context = new WebContext(webExchange);
        context.setVariable("User", User);//charger l'utilisateur
        if(User== null) {
            resp.sendRedirect("connexion");//si utilisateur non connecté rediriger vers connexion
        }
        ListeDao ListeDao = new ListeDaoImpl();
        if(ListeDao.VerifAdmin(User) == 1) { //verification du status utilisateur pour la gestion des utilisateurs
            context.setVariable("gestion","Gestion Users");
        }else{
            context.setVariable("gestion","");
        }
        TemplateEngine templateEngine = createTemplateEngine(application);

        // Utiliser un StringWriter pour stocker le contenu généré par Thymeleaf
        StringWriter thymeleafOutput = new StringWriter();
        templateEngine.process("Programme", context, thymeleafOutput);

        // Ajouter le contenu généré par Thymeleaf au contenu manuel
        StringBuilder content = new StringBuilder(thymeleafOutput.toString());

        // Ajouter le reste du contenu généré manuellement
        final ProgrammeDao ProgrammeDao = new ProgrammeDaoImpl();
        int nbProgrammes = 3;
        int i = 0;
        content.append("<main id = \"principal\">");
        for (i = 1; i <= nbProgrammes; i++) {
            String nomProgramme = ProgrammeDao.getProgrammeNom(i);
            String descProgramme = ProgrammeDao.getProgrammeDescription(i);
                content.append("<flex>\n");
                if(i==1){
                    content.append("<flex id=\"Clairp\" class=\"case\">\n");}   //génération du style pour les cases de la liste des exercices en fonction du nombre d'exos
                if(i % 2 == 0){
                    content.append("<flex id=\"Sombre\" class=\"case\">\n");}
                if(i%2!=0 && i!=1){
                    content.append("<flex id=\"Clair\" class=\"case\">\n");}
            content.append("        <div class=\"tableau\">\n");
            content.append("<h2>").append(nomProgramme).append("</h2><hr/>\n");

            content.append("      <p>").append(descProgramme).append("</p>\n");
            content.append("    </div>\n");
            content.append("  </flex>");
            content.append("  </flex>");

        }

        content.append("</main>");
        content.append("</body>");
        content.append("</html>");


        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println(content.toString());
        out.close();
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        final ProgrammeDao ProgrammeDao = new ProgrammeDaoImpl();
        String choixProgrammeString = req.getParameter("programme");
        int choixProgramme = Integer.parseInt(choixProgrammeString);
        JakartaServletWebApplication application = createApplication(req.getServletContext());
        IWebExchange webExchange = application.buildExchange(req, resp);
        WebContext context = new WebContext(webExchange);
        String User = (String) req.getSession().getAttribute("User");
        context.setVariable("User", User);
        ListeDao ListeDao = new ListeDaoImpl();
        if(ListeDao.VerifAdmin(User) == 1) {
            context.setVariable("gestion","Gestion Users");
        }else{
            context.setVariable("gestion","");
        }

        TemplateEngine templateEngine = createTemplateEngine(application);
        StringWriter thymeleafOutput = new StringWriter();

        templateEngine.process("Programme", context, thymeleafOutput);

        // Ajouter le contenu généré par Thymeleaf au contenu manuel, pour les exercices à la place des programmes
        StringBuilder content = new StringBuilder(thymeleafOutput.toString());
        int i = 0;
        content.append("<main id = \"principal\">");
        for (i = 1; i <= ProgrammeDao.getExoProgrammeNombre(choixProgramme); i++) {
            String nomExo = ProgrammeDao.getExoProgrammeNom(choixProgramme,i);
            String descExo = ProgrammeDao.getExoProgrammeNom(choixProgramme,i);
            content.append("<flex>\n");
            if(i==1){content.append("   <img id = \"imgp1\" src=\"/img/imgExercices/").append(ProgrammeDao.getExoProgrammeURL(choixProgramme,i)).append("\">\n");
                content.append("<flex id=\"Clairp\" class=\"case\">\n");}
            if(i % 2 == 0){content.append("   <img id = \"imgp\" src=\"/img/imgExercices/").append(ProgrammeDao.getExoProgrammeURL(choixProgramme,i)).append("\">\n");
                content.append("<flex id=\"Sombre\" class=\"case\">\n");
            }
            if(i%2!=0 && i!=1){content.append("   <img id = \"imgp\" src=\"/img/imgExercices/").append(ProgrammeDao.getExoProgrammeURL(choixProgramme,i)).append("\">\n");
                content.append("<flex id=\"Clair\" class=\"case\">\n");}
            content.append("        <div class=\"tableau\">\n");
            content.append("<h2>").append(nomExo).append(" </h2><hr/>\n");
            content.append("      <p>").append(descExo);
            if(choixProgramme == 1) {
                content.append(". <br>4 séries de 8 à 12 répétitions. 2min de repos entre les séries").append("</p>\n");
            }
            if(choixProgramme == 2) {
                content.append(". <br>4 séries de 4 à 6 répétitions. 3 à 5 min de repos entre les séries").append("</p>\n");
            }
            if(choixProgramme == 3) {
                content.append(". <br>6 séries de 15 à 20 répétitions. 30s à 1min de repos entre les séries").append("</p>\n");
            }
            content.append("    </div>\n");
            content.append("  </flex>");
            content.append("  </flex>");

        }


        content.append("</main>");
        content.append("</body>");
        content.append("</html>");


        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println(content.toString());
        out.close();
    }
}

