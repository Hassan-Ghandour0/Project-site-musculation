package junia.devweb.gymdatabase.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import junia.devweb.gymdatabase.dao.ConnexionDao;
import junia.devweb.gymdatabase.dao.InscriptionDao;
import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.impl.ConnexionDaoImpl;
import junia.devweb.gymdatabase.dao.impl.InscriptionDaoImpl;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Objects;


@WebServlet("/liste")
public class ListeServlet extends GenericServlet {
    final ConnexionDao connexionDao = new ConnexionDaoImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        JakartaServletWebApplication application = createApplication(req.getServletContext());

        IWebExchange webExchange = application.buildExchange(req, resp);
        WebContext context = new WebContext(webExchange);
        String User = (String) req.getSession().getAttribute("User");
        context.setVariable("User", User);
        TemplateEngine templateEngine = createTemplateEngine(application);
        if(User== null) {
            resp.sendRedirect("connexion");
        }
        ListeDao ListeDao = new ListeDaoImpl();
        if(ListeDao.VerifAdmin(User) == 1) {
            context.setVariable("gestion","Gestion Users");
        }else{
            context.setVariable("gestion","");
        }
        // Utiliser un StringWriter pour stocker le contenu généré par Thymeleaf
        StringWriter thymeleafOutput = new StringWriter();
        templateEngine.process("Liste", context, thymeleafOutput);

        // Ajouter le contenu généré par Thymeleaf au contenu manuel
        StringBuilder content = new StringBuilder(thymeleafOutput.toString());


        // Ajouter le reste du contenu généré manuellement, ajouté de la même manière que dans ProgrammeServlet
        int nbExos = ListeDao.getMaxID();
        int i = 0;
        content.append("<main id = \"principal\">");
        for (i = 1; i <= ListeDao.getMaxID(); i++) {
            String nomExo = ListeDao.getNom(i);
            String descExo = ListeDao.getDescription(i);
            if (nomExo != null && descExo != null) {
                content.append("<flex>\n");
                if(i==1){content.append("   <img id = \"imgp1\" src=\"/img/imgExercices/").append(ListeDao.getImageURL(i)).append("\">\n");
                    content.append("<flex id=\"Clairp\" class=\"case\">\n");}
                if(i % 2 == 0){content.append("   <img id = \"imgp\" src=\"/img/imgExercices/").append(ListeDao.getImageURL(i)).append("\">\n");
                    content.append("<flex id=\"Sombre\" class=\"case\">\n");
                }
                if(i%2!=0 && i!=1){content.append("   <img id = \"imgp\" src=\"/img/imgExercices/").append(ListeDao.getImageURL(i)).append("\">\n");
                    content.append("<flex id=\"Clair\" class=\"case\">\n");}}
            content.append("        <div class=\"tableau\">\n");
            content.append("<h2>").append(nomExo).append(" </h2><hr/>\n");
            content.append("      <p>").append(descExo).append("</p>\n");
            boolean isFavorite = ListeDao.isExerciceInFavorites(User, nomExo); // Ajout de cette ligne
            content.append("<button id='favorisButton" + i + "' onclick=\"switchFavoris(" + i + ", \'" + nomExo + "\', \'" + User + "\')\">");

            if (isFavorite) {
                content.append("Supprimer des favoris");
            } else {
                content.append("Ajouter aux favoris");
            }

            content.append("</button>\n");
            content.append("    </div>\n");
            content.append("  </flex>");
            content.append("  </flex>");

        }
        //Ajout du bloc de création d'un exercice
        if(ListeDao.VerifAdmin(User) == 1) {
            content.append("<style>");
            content.append("  #blocreation { margin-top: 20px; text-align: center; margin-bottom: 50px }");
            content.append("  #nomExo, #description { width: 66%;display: block; margin: 10px auto; display: block; box-sizing: border-box; }");
            content.append("  #description { height: 100px;vertical-align: top; }");
            content.append("  #addButton { display: block; margin: 10px auto; padding: 8px 16px; background-color: #4fa3d1; color: #fff; border: none; border-radius: 4px; cursor: pointer; width : 66% }");
            content.append("</style>");
            content.append("<p id=\"blocreation\">");
            content.append("<form action=\"liste\" method=\"post\">");
            content.append("<input type=\"text\" id=\"nomExo\" name=\"nomExo\" placeholder=\"Nom de l'exercice\">");
            content.append("<input type=\"text\" id=\"description\" name=\"description\" placeholder=\"Description de l'exercice\">");
            content.append("<button type=\"submit\" id=\"addButton\" name=\"AddButon\">Ajouter</button>");
            content.append("</form></p>");

        }
        //javascript pour appeler le TooggleFavoriteServlet et ajouter/supprimer aux favoris
        content.append("<script>");
        content.append("function switchFavoris(nomExo, User) {");
        content.append("  console.log('Before XHR Request: nomExo=' + nomExo + ', username=' + User);");
        content.append("  var xhr = new XMLHttpRequest();");
        content.append("  xhr.onreadystatechange = function() {");
        content.append("    console.log('XHR State: ' + xhr.readyState + ', Status: ' + xhr.status);");
        content.append("    if (xhr.readyState === 4 && xhr.status === 200) {");
        content.append("      console.log('XHR Response: ' + xhr.responseText);");

        // Utiliser la méthode isExerciceInFavorites pour déterminer la valeur de isFavorite
        content.append("      var isFavorite = " + ListeDao.isExerciceInFavorites(User, " + nomExo + ") + ";");

    //récupérer les informations  du bouton correspondant
        content.append("      var button = document.getElementById('favorisButton' + nomExo);");

        content.append("      if (isFavorite) {");
        content.append("        button.innerHTML = 'Ajouter aux favoris';");
        content.append("      } else {");
        content.append("        button.innerHTML = 'Supprimer des favoris';");
        content.append("      }");
        content.append("    }");
        content.append("  };");
        content.append("  xhr.open('POST', '/toggleFavorite', true);");
        content.append("  xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');");
        content.append("  xhr.send('nomExo=' + encodeURIComponent(nomExo) + '&username=' + encodeURIComponent(User));");

        content.append("  console.log('After XHR Send');");
        content.append("}");
        content.append("</script>");





        content.append("</main>");
        content.append("</body>");
        content.append("</html>");


        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println(content.toString());
        out.close();
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        final ListeDao ListeDao = new ListeDaoImpl();
        String Recherche = req.getParameter("recherche");
        String AddNom = req.getParameter("nomExo");
        String AddDescription = req.getParameter("description");
        if(!Objects.equals(AddNom, "") && !Objects.equals(AddDescription, "") && AddDescription != null && AddNom != null){
            ListeDao.addExercice(AddNom,AddDescription);
            resp.setHeader("Refresh", "0"); //rafraichir la page pour récupérer les exercices apres un ajout
        }
        JakartaServletWebApplication application = createApplication(req.getServletContext());
        IWebExchange webExchange = application.buildExchange(req, resp);
        WebContext context = new WebContext(webExchange);
        String User = (String) req.getSession().getAttribute("User");
        context.setVariable("User", User);
        TemplateEngine templateEngine = createTemplateEngine(application);
        StringWriter thymeleafOutput = new StringWriter();
        templateEngine.process("Liste", context, thymeleafOutput);

        // Ajouter le contenu généré par Thymeleaf au contenu manuel
        StringBuilder content = new StringBuilder(thymeleafOutput.toString());
        int i = 0;
        content.append("<main id = \"principal\">");
        for (i = 1; i <= ListeDao.getRechercheNombre(Recherche); i++) {
            String nomExo = ListeDao.getRechercheNom(Recherche,i);
            String descExo = ListeDao.getRechercheDescription(Recherche,i);
            content.append("<flex>\n");
            if(i==1){content.append("   <img id = \"imgp1\" src=\"/img/imgExercices/").append(ListeDao.getRechercheURL(Recherche,i)).append("\">\n");
                content.append("<flex id=\"Clairp\" class=\"case\">\n");}
            if(i % 2 == 0){content.append("   <img id = \"imgp\" src=\"/img/imgExercices/").append(ListeDao.getRechercheURL(Recherche,i)).append("\">\n");
                content.append("<flex id=\"Sombre\" class=\"case\">\n");
            }
            if(i%2!=0 && i!=1){content.append("   <img id = \"imgp\" src=\"/img/imgExercices/").append(ListeDao.getRechercheURL(Recherche,i)).append("\">\n");
                content.append("<flex id=\"Clair\" class=\"case\">\n");}
            content.append("        <div class=\"tableau\">\n");
            content.append("<h2>").append(nomExo).append(" </h2><hr/>\n");
            content.append("      <p>").append(descExo).append("</p>\n");
            boolean isFavorite = ListeDao.isExerciceInFavorites(User, nomExo); // Ajout de cette ligne
            content.append("<button id='favorisButton" + i + "' onclick=\"switchFavoris(" + i + ", \'" + nomExo + "\', \'" + User + "\')\">");

            if (isFavorite) {
                content.append("Supprimer des favoris");
            } else {
                content.append("Ajouter aux favoris");
            }

            content.append("</button>\n");
            content.append("    </div>\n");
            content.append("  </flex>");
            content.append("  </flex>");

        }
        if(ListeDao.VerifAdmin(User) == 1) {
            content.append("<style>");
            content.append("  #blocreation { margin-top: 20px; text-align: center; margin-bottom: 50px }");
            content.append("  #nomExo, #description { width: 66%;display: block; margin: 10px auto; display: block; box-sizing: border-box; }");
            content.append("  #description { height: 100px;vertical-align: top; }");
            content.append("  #addButton { display: block; margin: 10px auto; padding: 8px 16px; background-color: #4fa3d1; color: #fff; border: none; border-radius: 4px; cursor: pointer; width : 66% }");
            content.append("</style>");
            content.append("<p id=\"blocreation\">");
            content.append("<form action=\"liste\" method=\"post\">");
            content.append("<input type=\"text\" id=\"nomExo\" name=\"nomExo\" placeholder=\"Nom de l'exercice\">");
            content.append("<input type=\"text\" id=\"description\" name=\"description\" placeholder=\"Description de l'exercice\">");
            content.append("<button type=\"submit\" id=\"addButton\" name=\"AddButon\">Ajouter</button>");
            content.append("</form></p>");

        }


        content.append("<script>");
        content.append("function switchFavoris(nomExo, User) {");
        content.append("  console.log('Before XHR Request: nomExo=' + nomExo + ', username=' + User);");
        content.append("  var xhr = new XMLHttpRequest();");
        content.append("  xhr.onreadystatechange = function() {");
        content.append("    console.log('XHR State: ' + xhr.readyState + ', Status: ' + xhr.status);");
        content.append("    if (xhr.readyState === 4 && xhr.status === 200) {");
        content.append("      console.log('XHR Response: ' + xhr.responseText);");

// Utiliser la méthode isExerciceInFavorites pour déterminer la valeur de isFavorite
        content.append("      var isFavorite = " + ListeDao.isExerciceInFavorites(User, " + nomExo + ") + ";");

// Placer la ligne suivante ici
        content.append("      var button = document.getElementById('favorisButton' + nomExo);");

        content.append("      if (isFavorite) {");
        content.append("        button.innerHTML = 'Ajouter aux favoris';");
        content.append("      } else {");
        content.append("        button.innerHTML = 'Supprimer des favoris';");
        content.append("      }");
        content.append("    }");
        content.append("  };");
        content.append("  xhr.open('POST', '/toggleFavorite', true);");
        content.append("  xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');");
        content.append("  xhr.send('nomExo=' + encodeURIComponent(nomExo) + '&username=' + encodeURIComponent(User));");

        content.append("  console.log('After XHR Send');");
        content.append("}");
        content.append("</script>");





        content.append("</main>");
        content.append("</body>");
        content.append("</html>");


        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println(content.toString());
        out.close();
    }
}

