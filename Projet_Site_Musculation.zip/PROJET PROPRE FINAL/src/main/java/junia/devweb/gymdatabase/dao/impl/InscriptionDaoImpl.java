package junia.devweb.gymdatabase.dao.impl;

import de.mkammerer.argon2.Argon2;
import de.mkammerer.argon2.Argon2Factory;
import junia.devweb.gymdatabase.dao.InscriptionDao;

import javax.sql.DataSource;
import java.sql.*;

import static junia.devweb.gymdatabase.dao.impl.DataSourceProvider.getDataSource;

public class InscriptionDaoImpl implements InscriptionDao {

    public int PseudoExiste(String pseudo) {
        int resultSet = 0;
        String sql = "SELECT COUNT(*) AS count FROM utilisateur WHERE Nickname=?";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setString(1, pseudo);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        resultSet = result.getInt("count");
                        return resultSet;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean EmailValid(String email) {

        return email.contains("@");
    }

    @Override
    public boolean Inscription(String pseudo, String prenom, String nom, String email, String mdp, String confirmmdp) {
        System.out.println("Inscription");
        if (PseudoExiste(pseudo)>0) {
            return false;
        }

        if (!EmailValid(email)) {
            return false;
        }
        if (!MdpValide(mdp)){
            return false;
        }

        if(!MdpEqual(mdp,confirmmdp)){
            return false;
        }
        Argon2 argon2 = Argon2Factory.create();
        String motdepassehash= argon2.hash(10,65536,1,mdp);
        System.out.println("Mot de passe hashé en argon2 : "+motdepassehash);
        String sql = "INSERT INTO utilisateur (Nickname, prenom, nom, email, mot_de_passe) VALUES (?, ?, ?, ?, ?)";
        try {
            DataSource dataSource = getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement statement = cnx.prepareStatement(sql)) {
                statement.setString(1, pseudo);
                statement.setString(2, prenom);
                statement.setString(3, nom);
                statement.setString(4, email);
                statement.setString(5, motdepassehash);

                int AjoutValide = statement.executeUpdate();
                return AjoutValide > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;

    }
    @Override
    public boolean MdpValide(String password) {
        // Vérifier la présence d'une minuscule
        if (!password.matches(".*[a-z].*")) {
            return false;
        }
        // Vérifier la présence d'une majuscule
        if (!password.matches(".*[A-Z].*")) {
            return false;
        }
        // Vérifier la présence d'un chiffre
        if (!password.matches(".*\\d.*")) {
            return false;
        }
        // Vérifier la présence d'un caractère spécial (par exemple, !@#$%^&*()-_=+[]{}|;:'\",.<>/?)
        if (!password.matches(".*[!@#$%^&*()-_=+\\[\\]{}|;:'\",.<>/?].*")) {
            return false;
        }
        // Si toutes les conditions sont remplies, le mot de passe est valide
        return true;
    }
    @Override
    public boolean MdpEqual(String mdp, String ConfirmMdp){
        if(mdp.trim().equals(ConfirmMdp.trim())){
            return true;
        }
        else {
            return false;
        }
    }
}
