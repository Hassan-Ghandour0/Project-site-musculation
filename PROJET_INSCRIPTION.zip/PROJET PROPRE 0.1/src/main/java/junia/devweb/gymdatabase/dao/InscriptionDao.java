package junia.devweb.gymdatabase.dao;

public interface InscriptionDao {
    boolean Inscription(String pseudo, String prenom, String nom, String email, String password);

}