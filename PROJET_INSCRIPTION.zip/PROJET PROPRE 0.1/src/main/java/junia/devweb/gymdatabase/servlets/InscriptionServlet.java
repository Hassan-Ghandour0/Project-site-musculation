package junia.devweb.gymdatabase.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import junia.devweb.gymdatabase.dao.InscriptionDao;
import junia.devweb.gymdatabase.dao.impl.InscriptionDaoImpl;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;

@WebServlet("/inscription")
public class InscriptionServlet extends GenericServlet {

    InscriptionDao inscriptionDao = new InscriptionDaoImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JakartaServletWebApplication application = createApplication(req.getServletContext());
        IWebExchange webExchange = application.buildExchange(req , resp);
        WebContext context = new WebContext(webExchange);

        TemplateEngine templateEngine = createTemplateEngine(application);
        templateEngine.process("inscription", context, resp.getWriter());
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String newUser = req.getParameter("newUser");
        String prenom = req.getParameter("Prenom");
        String nom = req.getParameter("Nom");
        String email = req.getParameter("Email");
        String newMdp = req.getParameter("newMdp");
        boolean InscriptionValide = inscriptionDao.Inscription(newUser, prenom, nom, email, newMdp);

        if (InscriptionValide) {
            resp.sendRedirect("home");
        } else {
            String erreurMsg2;
            if (((InscriptionDaoImpl) inscriptionDao).PseudoExiste(newUser)) {
                erreurMsg2="Le pseudo existe déjà";
                req.setAttribute("erreurMsg2", erreurMsg2);
            }
            else if (!((InscriptionDaoImpl) inscriptionDao).EmailValid(email)) {
                erreurMsg2="L'Email n'est pas conforme";
                req.setAttribute("erreurMsg2", erreurMsg2);
            }
            else if (!((InscriptionDaoImpl) inscriptionDao).MdpValide(newMdp)) {
                erreurMsg2="Le mot de passe n'est pas conforme";
                req.setAttribute("erreurMsg2", erreurMsg2);
            }
            JakartaServletWebApplication application = createApplication(req.getServletContext());
            IWebExchange webExchange = application.buildExchange(req, resp);
            WebContext context = new WebContext(webExchange);

            TemplateEngine templateEngine = createTemplateEngine(application);
            templateEngine.process("inscription", context, resp.getWriter());
        }
    }
}
