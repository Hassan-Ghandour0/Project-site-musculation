package junia.devweb.gymdatabase.dao;

import junia.devweb.gymdatabase.dao.impl.InscriptionDaoImpl;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class InscriptionDaoImplTest {

    @Test
    public void testInscription() {
        InscriptionDao inscriptionDao = new InscriptionDaoImpl();

        // Remplacez les valeurs par celles que vous souhaitez tester
        String pseudo = "T2";
        String prenom = "Scarlett";
        String nom = "Johansson";
        String email = "aaaadqsd@fgdfgdfqg";
        String mdp = "Password123$";

        // Vérifier que le pseudo n'existe pas déjà
        assertFalse(((InscriptionDaoImpl) inscriptionDao).PseudoExiste(pseudo), "Le pseudo existe déjà.");

        // test pour la validation de l'email
        assertTrue(((InscriptionDaoImpl) inscriptionDao).EmailValid(email), "L'email n'est pas conforme.");

        // test pour la validation du mdp
        assertTrue(((InscriptionDaoImpl) inscriptionDao).MdpValide(mdp),"le mot de passe n'est pas conforme");

        // Appel de la méthode Inscription avec les valeurs spécifiées
        boolean inscriptionValide = inscriptionDao.Inscription(pseudo, prenom, nom, email, mdp);

        // Vérifier si l'inscription est réussie
        assertTrue(inscriptionValide, "L'inscription devrait être réussie.");
    }
}
