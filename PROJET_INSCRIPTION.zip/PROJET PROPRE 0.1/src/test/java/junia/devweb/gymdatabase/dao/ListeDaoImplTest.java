package junia.devweb.gymdatabase.dao;

import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ListeDaoImplTest {

    @Test
    public void testGetDescription() {
        String dbUrl = "jdbc:mariadb://localhost:3306/shonenmuscuprojet";
        String dbUser = "mohamed";
        String dbPassword = "31Mc@x!w";

        ListeDao listeDao = new ListeDaoImpl();

        // Remplacez l'ID par celui que vous souhaitez tester
        Integer idExercice = 1;

        // Appel de la méthode getDescription avec l'ID spécifié
        String descriptionExo = listeDao.getDescription(idExercice);

        // Vérifier si la description n'est pas nulle
        assertNotNull(descriptionExo, "La description ne devrait pas être nulle.");

        // Afficher la description
        System.out.println("Description de l'exercice avec l'ID " + idExercice + ": " + descriptionExo);
    }

    @Test
    public void testGetNom() {
        ListeDao listeDao = new ListeDaoImpl();

        // Remplacez l'ID par celui que vous souhaitez tester
        Integer idExercice = 1;

        // Appel de la méthode getNom avec l'ID spécifié
        String nomExo = listeDao.getNom(idExercice);

        // Vérifier si le nom n'est pas nul
        assertNotNull(nomExo, "Le nom ne devrait pas être nul.");

        // Afficher le nom
        System.out.println("Nom de l'exercice avec l'ID " + idExercice + ": " + nomExo);
    }
}

