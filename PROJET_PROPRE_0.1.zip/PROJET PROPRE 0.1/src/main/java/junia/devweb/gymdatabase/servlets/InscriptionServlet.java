package junia.devweb.gymdatabase.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import junia.devweb.gymdatabase.dao.InscriptionDao;
import junia.devweb.gymdatabase.dao.impl.InscriptionDaoImpl;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;

@WebServlet("/inscription")
public class InscriptionServlet extends GenericServlet {

    final InscriptionDao inscriptionDao = new InscriptionDaoImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JakartaServletWebApplication application = createApplication(req.getServletContext());
        IWebExchange webExchange = application.buildExchange(req , resp);
        WebContext context = new WebContext(webExchange);

        TemplateEngine templateEngine = createTemplateEngine(application);
        templateEngine.process("inscription", context, resp.getWriter());
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String newUser = req.getParameter("newUser");
        String prenom = req.getParameter("Prenom");
        String nom = req.getParameter("Nom");
        String email = req.getParameter("Email");
        String newMdp = req.getParameter("newMdp");
        boolean InscriptionValide = inscriptionDao.Inscription(newUser, prenom, nom, email, newMdp);

        if (InscriptionValide) {
            resp.sendRedirect("connexion");
        } else {
            String erreurMsg2 = "ratio";
            if(inscriptionDao.PseudoExiste(prenom)){
                erreurMsg2 = "Utilisateur invalide";}
            if(inscriptionDao.EmailValid(prenom)){
                erreurMsg2 = "Utilisateur invalide";}
            req.setAttribute("erreurMsg2", erreurMsg2);

            JakartaServletWebApplication application = createApplication(req.getServletContext());
            IWebExchange webExchange = application.buildExchange(req, resp);
            WebContext context = new WebContext(webExchange);

            TemplateEngine templateEngine = createTemplateEngine(application);
            templateEngine.process("inscription", context, resp.getWriter());
        }
    }
}
