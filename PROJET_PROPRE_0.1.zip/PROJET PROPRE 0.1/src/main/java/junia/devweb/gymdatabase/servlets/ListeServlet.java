package junia.devweb.gymdatabase.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/Liste")
public class ListeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Récupérez l'ID de la requête
        String idParam = request.getParameter("id");

        if (idParam != null) {
            try {
                int id = Integer.parseInt(idParam);
                // Supposons que vous avez une classe ListeDao qui gère l'accès à la base de données
                ListeDao listeDao = new ListeDaoImpl(); // Instanciation de l'implémentation du DAO
                String description = listeDao.getDescription(id);
                String nom = listeDao.getNom(id);

                // Convertissez les données en format JSON
                String jsonResponse = "{ \"description\": \"" + description + "\", \"nom\": \"" + nom + "\" }";

                // Configurez l'en-tête de la réponse
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");

                // Écrivez les données JSON dans le flux de sortie
                try (PrintWriter out = response.getWriter()) {
                    out.print(jsonResponse);
                }
            } catch (NumberFormatException e) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("ID invalide");
            }
        } else {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("ID manquant dans la requête");
        }
    }
}
