package junia.devweb.gymdatabase.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import junia.devweb.gymdatabase.dao.UserDao;
import junia.devweb.gymdatabase.dao.impl.UserProfileDaoImpl;
import org.thymeleaf.TemplateEngine;

import org.thymeleaf.context.Context;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import static junia.devweb.gymdatabase.dao.impl.DataSourceProvider.dataSource;

@WebServlet("/user")
public class UserProfileServlet extends GenericServlet {
    private UserDao userDao = new UserProfileDaoImpl(dataSource);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int userId =1;
        req.getSession().setAttribute("userId", userId);
        Map<String, Object> user = userDao.getUserById(userId);

        JakartaServletWebApplication application = createApplication(req.getServletContext());

        TemplateEngine templateEngine = createTemplateEngine(application);
        Context context = new Context();
        context.setVariable("user", user);

        StringWriter thymeleafOutput = new StringWriter();
        templateEngine.process("Profil", context, thymeleafOutput);

        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println(thymeleafOutput.toString());
        out.close();
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String currentPassword = req.getParameter("currentPassword");
        String newPassword = req.getParameter("newPassword");
        Integer userIdObject = (Integer) req.getSession().getAttribute("userId");
        resp.setContentType("text/html");

        try (PrintWriter out = resp.getWriter()) {
            if (userIdObject != null) {
                int userId = userIdObject.intValue();

                Map<String, Object> user = userDao.getUserById(userId);

                if (user != null) {
                    String storedPassword = (String) user.get("mot_de_passe");

                    if (currentPassword.equals(storedPassword)) {

                        userDao.updatePassword(userId, newPassword);
                        out.println("Mot de passe changé avec succès !");
                    } else {

                        out.println("Échec du changement de mot de passe. Veuillez vérifier votre mot de passe actuel.");
                    }
                }
            }
        }
    }
}
