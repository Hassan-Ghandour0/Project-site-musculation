package junia.devweb.gymdatabase.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.javacinee.dao.impl.DataSourceProvider;

public class ListeDaoImpl implements ListeDao {

    @Override
    public String getDescription(Integer id) {
        String descriptionExo = null;
        String sql = "SELECT description FROM exercice WHERE id=?";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        descriptionExo = result.getString("description");
                    }
                }
            }
        } catch (SQLException e) {
            // Gérer l'exception de manière appropriée
            e.printStackTrace();
        }
        return descriptionExo;
    }

    @Override
    public String getNom(Integer id) {
        String nomExo = null;
        String sql = "SELECT nom FROM exercice WHERE id=?";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        nomExo = result.getString("nom");
                    }
                }
            }
        } catch (SQLException e) {
            // Gérer l'exception de manière appropriée
            e.printStackTrace();
        }
        return nomExo;
    }
}
