package junia.devweb.gymdatabase.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import junia.devweb.gymdatabase.dao.ListeDao;

public class ListeDaoImpl implements ListeDao {

    @Override
    public String getDescription(Integer id) {
        String descriptionExo = null;
        String sql = "SELECT description FROM exercice WHERE id=?";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        descriptionExo = result.getString("description");
                    }
                }
            }
        } catch (SQLException e) {
            // Gérer l'exception de manière appropriée
            e.printStackTrace();
        }
        return descriptionExo;
    }

    @Override
    public String getNom(Integer id) {
        String nomExo = null;
        String sql = "SELECT nom FROM exercice WHERE id=?";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        nomExo = result.getString("nom");
                    }
                }
            }
        } catch (SQLException e) {
            // Gérer l'exception de manière appropriée
            e.printStackTrace();
        }
        return nomExo;
    }

    @Override
    public int getMaxID() {
        int ID = 0;
        String sql = "SELECT MAX(id) as maxID FROM exercice";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql);
                 ResultSet result = preparedStatement.executeQuery()) {

                if (result.next()) {
                    ID = result.getInt("maxID");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ID;
    }

    @Override
    public String getImageURL(Integer id) {
        String ImageURL = null;
        String sql = "SELECT image_url FROM exercice WHERE id=?";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        ImageURL = result.getString("image_url");
                    }
                }
            }
        } catch (SQLException e) {
            // Gérer l'exception de manière appropriée
            e.printStackTrace();
        }
        return ImageURL;
    }



    @Override
    public String getRechercheNom(String recherche, int number) {
        String rechercheExo = null;
        String sql = "SELECT *\n" +
                "FROM (\n" +
                "         SELECT nom, ROW_NUMBER() OVER (ORDER BY id) AS RowNum\n" +
                "         FROM exercice WHERE nom LIKE CONCAT(?,'%')" + // Utiliser || pour concaténer les chaînes
                "     ) AS sub\n" +
                "WHERE RowNum = ?;";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setString(1, recherche);
                preparedStatement.setInt(2, number);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        rechercheExo = result.getString("nom");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rechercheExo;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
    @Override
    public String getRechercheDescription(String recherche, int number) {
        String rechercheDescription = null;
        String sql = "SELECT *\n" +
                "FROM (\n" +
                "         SELECT description, ROW_NUMBER() OVER (ORDER BY id) AS RowNum\n" +
                "         FROM exercice WHERE nom LIKE CONCAT(?,'%')" +
                "     ) AS sub\n" +
                "WHERE RowNum = ?;";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setString(1, recherche);
                preparedStatement.setInt(2, number);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        rechercheDescription = result.getString("description");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rechercheDescription;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public String getRechercheURL(String recherche, int number) {
        String rechercheURL = null;
        String sql = "SELECT *\n" +
                "FROM (\n" +
                "         SELECT image_url, ROW_NUMBER() OVER (ORDER BY id) AS RowNum\n" +
                "         FROM exercice WHERE nom LIKE CONCAT(?,'%')" +
                "     ) AS sub\n" +
                "WHERE RowNum = ?;";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setString(1, recherche);
                preparedStatement.setInt(2, number);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        rechercheURL = result.getString("image_url");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rechercheURL;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public int getRechercheNombre(String recherche) {
        int rechercheNombre = 0;
        String sql = "SELECT COUNT(*) AS count FROM exercice WHERE nom LIKE CONCAT(?,'%')";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setString(1, recherche+"%");
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        rechercheNombre = result.getInt("count");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rechercheNombre;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}