package junia.devweb.gymdatabase.dao.impl;

import junia.devweb.gymdatabase.dao.ConnexionDao;
import junia.devweb.javacinee.dao.impl.DataSourceProvider;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConnexionDaoImpl implements ConnexionDao {

    @Override
    public String getPassword(String nickname) {
        String motDePasse = null;
        String sql = "SELECT * FROM utilisateur WHERE Nickname=?";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setString(1, nickname);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        motDePasse = result.getString("mot_de_passe");
                    }
                }
            }
        } catch (SQLException e) {
            // Gérer l'exception de manière appropriée (par exemple, lancer une nouvelle exception)
            e.printStackTrace();
        }
        return motDePasse;
    }
}
