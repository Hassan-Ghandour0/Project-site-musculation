package junia.devweb.gymdatabase.dao;

public interface ListeDao {

	 String getDescription(Integer id);
	 String getNom(Integer id);

    int getMaxID();

	String getImageURL(Integer id);

	int getRechercheNombre(String recherche);

	String getRechercheNom(String recherche, int number);

	String getRechercheDescription(String recherche, int number);

	String getRechercheURL(String recherche, int number);
}
