package junia.devweb.gymdatabase.dao;

import java.util.Map;

public interface UserDao {
    Map<String, Object> getUserById(int userId);
    void updatePassword(int userId, String newPassword);
}
