package junia.devweb.gymdatabase.dao.impl;

import junia.devweb.gymdatabase.dao.UserDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;

public class UserProfileDaoImpl implements UserDao {

    private final DataSource dataSource;

    public UserProfileDaoImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    private Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    @Override
    public Map<String, Object> getUserById(int userId) {
        Map<String, Object> user = new HashMap<>();
        String sql = "SELECT * FROM `utilisateur` WHERE id=?";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, userId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    user.put("id", resultSet.getInt("id"));
                    user.put("nickname", resultSet.getString("nickname"));
                    user.put("nom", resultSet.getString("nom"));
                    user.put("prenom", resultSet.getString("prenom"));
                    user.put("email", resultSet.getString("email"));
                    user.put("mot_de_passe", resultSet.getString("mot_de_passe"));
                    user.put("date_inscription", resultSet.getString("date_inscription"));
                    user.put("role", resultSet.getString("role"));

                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }
    @Override
    public void updatePassword(int userId, String newPassword) {
        String sql = "UPDATE `utilisateur` SET mot_de_passe=? WHERE id=?";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, newPassword);
            preparedStatement.setInt(2, userId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
