package junia.devweb.gymdatabase.dao;

public interface ListeDao {

	 String getDescription(Integer id);
	 String getNom(Integer id);
}
