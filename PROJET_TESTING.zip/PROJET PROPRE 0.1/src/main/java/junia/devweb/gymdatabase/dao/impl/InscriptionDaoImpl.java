package junia.devweb.gymdatabase.dao.impl;

import junia.devweb.gymdatabase.dao.InscriptionDao;

import java.sql.*;

public class InscriptionDaoImpl implements InscriptionDao {

    public boolean PseudoExiste(String pseudo) {
        try (Connection connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/shonenmuscuprojet", "mohamed", "31Mc@x!w")) {
            String sql = "SELECT COUNT(*) FROM utilisateur WHERE Nickname = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, pseudo);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        return resultSet.getInt(1) > 0;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public boolean EmailValid(String email) {

        return email.contains("@");
    }
    @Override
    public boolean Inscription(String pseudo, String prenom, String nom, String email, String mdp) {

        if (PseudoExiste(pseudo)) {
            return false;
        }

        if (!EmailValid(email)) {
            return false;
        }

        try (Connection connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/shonenmuscuprojet", "mohamed", "31Mc@x!w")) {
            String sql = "INSERT INTO utilisateur (Nickname, prenom, nom, email, mot_de_passe) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, pseudo);
                statement.setString(2, prenom);
                statement.setString(3, nom);
                statement.setString(4, email);
                statement.setString(5, mdp);

                int AjoutValide = statement.executeUpdate();
                return AjoutValide > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
