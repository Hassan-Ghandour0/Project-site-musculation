package junia.devweb.projet.servlets;

import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServlet;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.WebApplicationTemplateResolver;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

/**
 * Classe abstraite qui contient le code commun pour la gestion de la creation du moteur de template de thymeleaf afin d'éviter de répéter le code
 * dans chaque Servlet
 * Cette classe étend HttpServlet
 */
public abstract class ShonenServlet  extends HttpServlet {

    protected JakartaServletWebApplication createWebApplication(ServletContext servletContext) {
        return JakartaServletWebApplication.buildApplication(servletContext);
    }
    /**
     *
     * Méthode qui créé un moteur de template
     */
    protected TemplateEngine createTemplateEngine(JakartaServletWebApplication application) {
        // Création du resolver pour récupérer les templates
        WebApplicationTemplateResolver templateResolver = new WebApplicationTemplateResolver(application);
        templateResolver.setTemplateMode(TemplateMode.HTML);
        templateResolver.setPrefix("/WEB-INF/templates/");
        templateResolver.setSuffix(".html");

        // Création du moteur de template auquel on assigne le resolver
        TemplateEngine templateEngine = new TemplateEngine();
        templateEngine.setTemplateResolver(templateResolver);

        // on retourne le moteur de template pour que chaque servlet appelante puisse positionner le context
        // et appeler la méthode process sur le bon template
        return templateEngine;
    }
}