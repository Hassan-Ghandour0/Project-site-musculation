package junia.devweb.gymdatabase.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import junia.devweb.gymdatabase.dao.ConnexionDao;
import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.impl.ConnexionDaoImpl;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;


@WebServlet("/favoris")
public class FavorisServlet extends GenericServlet {
    final ConnexionDao connexionDao = new ConnexionDaoImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        JakartaServletWebApplication application = createApplication(req.getServletContext());

        IWebExchange webExchange = application.buildExchange(req, resp);
        WebContext context = new WebContext(webExchange);
        String User = (String) req.getSession().getAttribute("User");
        if(User== null) {
            resp.sendRedirect("connexion");
        }
        context.setVariable("User", User);
        ListeDao ListeDao = new ListeDaoImpl();
        if(ListeDao.VerifAdmin(User) == 1) {
            context.setVariable("gestion","Gestion Users");
        }else{
            context.setVariable("gestion","");
        }
        TemplateEngine templateEngine = createTemplateEngine(application);

        // Utiliser un StringWriter pour stocker le contenu généré par Thymeleaf
        StringWriter thymeleafOutput = new StringWriter();
        templateEngine.process("Favoris", context, thymeleafOutput);

        // Ajouter le contenu généré par Thymeleaf au contenu manuel
        StringBuilder content = new StringBuilder(thymeleafOutput.toString());


        // Ajouter le reste du contenu généré manuellement
        int nbExos = ListeDao.getMaxID();
        int i = 0;
        int r = 0;
        content.append("<main id = \"principal\">");
        for (i = 1; i <= ListeDao.getMaxID(); i++) {
            String nomExo = ListeDao.getNom(i);
            String descExo = ListeDao.getDescription(i);
            if (ListeDao.isExerciceInFavorites(User, nomExo)) {
                r++;
                if (nomExo != null && descExo != null) {
                    content.append("<flex>\n");
                    if (r == 1) {
                        content.append("   <img id = \"imgp1\" src=\"/img/imgExercices/").append(ListeDao.getImageURL(i)).append("\">\n");
                        content.append("<flex id=\"Clairp\" class=\"case\">\n");
                    }
                    if (r % 2 == 0) {
                        content.append("   <img id = \"imgp\" src=\"/img/imgExercices/").append(ListeDao.getImageURL(i)).append("\">\n");
                        content.append("<flex id=\"Sombre\" class=\"case\">\n");
                    }
                    if (r % 2 != 0 && i != 1) {
                        content.append("   <img id = \"imgp\" src=\"/img/imgExercices/").append(ListeDao.getImageURL(i)).append("\">\n");
                        content.append("<flex id=\"Clair\" class=\"case\">\n");
                    }
                }

                content.append("        <div class=\"tableau\">\n");
                content.append("<h2>").append(nomExo).append(" </h2><hr/>\n");
                content.append("      <p>").append(descExo).append("</p>\n");
                content.append("    </div>\n");
                content.append("  </flex>");
                content.append("  </flex>");
            }
        }




        content.append("</main>");
        content.append("</body>");
        content.append("</html>");


        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println(content.toString());
        out.close();
    }


}

