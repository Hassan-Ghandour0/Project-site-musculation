package junia.devweb.gymdatabase.dao;

public interface ConnexionDao {

	 String getPassword(String Nickname);
}
