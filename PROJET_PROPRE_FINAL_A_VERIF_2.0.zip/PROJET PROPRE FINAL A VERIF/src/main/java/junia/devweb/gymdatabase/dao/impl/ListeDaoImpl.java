package junia.devweb.gymdatabase.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import junia.devweb.gymdatabase.dao.ListeDao;

public class ListeDaoImpl implements ListeDao {

    @Override
    public String getDescription(Integer id) {
        String descriptionExo = null;
        String sql = "SELECT * FROM (SELECT description, ROW_NUMBER() OVER (ORDER BY id) AS RowNum FROM exercice) as sub WHERE RowNum = ?";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        descriptionExo = result.getString("description");
                    }
                }
            }
        } catch (SQLException e) {
            // Gérer l'exception de manière appropriée
            e.printStackTrace();
        }
        return descriptionExo;
    }

    @Override
    public String getNom(Integer id) {
        String nomExo = null;
        String sql = "SELECT * FROM (SELECT nom, ROW_NUMBER() OVER (ORDER BY id) AS RowNum FROM exercice) as sub WHERE RowNum = ?";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        nomExo = result.getString("nom");
                    }
                }
            }
        } catch (SQLException e) {
            // Gérer l'exception de manière appropriée
            e.printStackTrace();
        }
        return nomExo;
    }

    @Override
    public int getMaxID() {
        int ID = 0;
        String sql = "SELECT COUNT(*) as maxID FROM exercice WHERE nom IS NOT NULL";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql);
                 ResultSet result = preparedStatement.executeQuery()) {

                if (result.next()) {
                    ID = result.getInt("maxID");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ID;
    }

    @Override
    public String getImageURL(Integer id) {
        String ImageURL = null;
        String sql = "SELECT * FROM (SELECT image_url, ROW_NUMBER() OVER (ORDER BY id) AS RowNum FROM exercice) as sub WHERE RowNum = ?";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        ImageURL = result.getString("image_url");
                    }
                }
            }
        } catch (SQLException e) {
            // Gérer l'exception de manière appropriée
            e.printStackTrace();
        }
        return ImageURL;
    }


    @Override
    public String getRechercheNom(String recherche, int number) {
        String rechercheExo = null;
        String sql = "SELECT *\n" +
                "FROM (\n" +
                "         SELECT nom, ROW_NUMBER() OVER (ORDER BY id) AS RowNum\n" +
                "         FROM exercice WHERE nom LIKE CONCAT('%',?,'%')" + // Utiliser || pour concaténer les chaînes
                "     ) AS sub\n" +
                "WHERE RowNum = ?;";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setString(1, recherche);
                preparedStatement.setInt(2, number);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        rechercheExo = result.getString("nom");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rechercheExo;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public String getRechercheDescription(String recherche, int number) {
        String rechercheDescription = null;
        String sql = "SELECT *\n" +
                "FROM (\n" +
                "         SELECT description, ROW_NUMBER() OVER (ORDER BY id) AS RowNum\n" +
                "         FROM exercice WHERE nom LIKE CONCAT('%',?,'%')" +
                "     ) AS sub\n" +
                "WHERE RowNum = ?;";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setString(1, recherche);
                preparedStatement.setInt(2, number);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        rechercheDescription = result.getString("description");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rechercheDescription;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public String getRechercheURL(String recherche, int number) {
        String rechercheURL = null;
        String sql = "SELECT *\n" +
                "FROM (\n" +
                "         SELECT image_url, ROW_NUMBER() OVER (ORDER BY id) AS RowNum\n" +
                "         FROM exercice WHERE nom LIKE CONCAT('%',?,'%')" +
                "     ) AS sub\n" +
                "WHERE RowNum = ?;";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setString(1, recherche);
                preparedStatement.setInt(2, number);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        rechercheURL = result.getString("image_url");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rechercheURL;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public int getRechercheNombre(String recherche) {
        int rechercheNombre = 0;
        String sql = "SELECT COUNT(*) AS count FROM exercice WHERE nom LIKE CONCAT('%',?,'%')";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setString(1, recherche + "%");
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        rechercheNombre = result.getInt("count");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rechercheNombre;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int VerifAdmin(String User) {
        int rechercheAdmin = 0;
        String sql = "SELECT Count(*) AS count from utilisateur WHERE utilisateur.Nickname LIKE ? and role LIKE 'administrateur'";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setString(1, User);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        rechercheAdmin = result.getInt("count");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rechercheAdmin;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public void addExercice(String nomExo, String description) {
        String sql = "INSERT INTO exercice (nom,description) VALUES (?,?)";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setString(1, nomExo);
                preparedStatement.setString(2, description);
                try (ResultSet result = preparedStatement.executeQuery()) {

                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public void switchFavoris(String nomExo, String Username) {
        int favNum = 0;
        String getSql = "SELECT count(*) AS count FROM exercice, favoris, utilisateur WHERE exercice.id = favoris.id_exercice AND utilisateur.id = favoris.id_utilisateur AND exercice.nom = ? AND utilisateur.Nickname = ?";

        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(getSql)) {
                preparedStatement.setString(1, nomExo);
                preparedStatement.setString(2, Username);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        favNum = result.getInt("count");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        String sendSql;
        if (favNum == 1) {
            // If the exercise is already in favorites, remove it
            sendSql = "DELETE FROM favoris WHERE id_exercice = (SELECT id FROM exercice WHERE nom = ? LIMIT 1) AND id_utilisateur = (SELECT id FROM utilisateur WHERE Nickname = ? LIMIT 1)";
        } else {
            // If the exercise is not in favorites, add it
            sendSql = "INSERT INTO favoris (id_exercice, id_utilisateur) VALUES ((SELECT id FROM exercice WHERE nom = ? LIMIT 1), (SELECT id FROM utilisateur WHERE Nickname = ? LIMIT 1))";
        }

        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sendSql)) {
                preparedStatement.setString(1, nomExo);
                preparedStatement.setString(2, Username);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    @Override
    public boolean isExerciceInFavorites(String Username,String nomExo) {
        boolean isFavorite = false;
        String getSql = "SELECT count(*) AS count FROM exercice, favoris, utilisateur WHERE exercice.id = favoris.id_exercice AND utilisateur.id = favoris.id_utilisateur AND exercice.nom = ? AND utilisateur.Nickname = ?";

        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(getSql)) {
                preparedStatement.setString(1, nomExo);
                preparedStatement.setString(2, Username);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        isFavorite = result.getInt("count") == 1;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Gérer l'exception de manière appropriée (par exemple, journalisation, renvoi d'une exception spécifique)
        }

        return isFavorite;
    }


}