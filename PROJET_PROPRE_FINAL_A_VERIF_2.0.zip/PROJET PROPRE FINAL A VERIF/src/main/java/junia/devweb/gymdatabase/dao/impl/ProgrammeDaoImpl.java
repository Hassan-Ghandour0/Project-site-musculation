package junia.devweb.gymdatabase.dao.impl;

import junia.devweb.gymdatabase.dao.ProgrammeDao;
import junia.devweb.gymdatabase.dao.impl.DataSourceProvider;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProgrammeDaoImpl implements ProgrammeDao {

    @Override
    public String getProgrammeDescription(Integer id) {
        String descriptionExo = null;
        String sql = "SELECT * FROM (SELECT description, ROW_NUMBER() OVER (ORDER BY id) AS RowNum FROM programme) as sub WHERE RowNum = ?";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        descriptionExo = result.getString("description");
                    }
                }
            }
        } catch (SQLException e) {
            // Gérer l'exception de manière appropriée
            e.printStackTrace();
        }
        return descriptionExo;
    }

    @Override
    public String getProgrammeNom(Integer id) {
        String nomExo = null;
        String sql = "SELECT * FROM (SELECT nom, ROW_NUMBER() OVER (ORDER BY id) AS RowNum FROM programme) as sub WHERE RowNum = ?";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        nomExo = result.getString("nom");
                    }
                }
            }
        } catch (SQLException e) {
            // Gérer l'exception de manière appropriée
            e.printStackTrace();
        }
        return nomExo;
    }


    @Override
    public String getExoProgrammeNom(int programme, int number) {
        String rechercheExo = null;
        String sql = "SELECT *\n" +
                "FROM (\n" +
                "         SELECT exercice.nom, ROW_NUMBER() OVER (ORDER BY exercice.id) AS RowNum\n" +
                "         FROM exercice,programme_exercice,programme WHERE programme.id = programme_exercice.programme_id " +
                "                AND programme_exercice.exercice_id = exercice.id AND programme_id = ?" +
                "     ) AS sub\n" +
                "WHERE RowNum = ?;";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setInt(1, programme);
                preparedStatement.setInt(2, number);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        rechercheExo = result.getString("nom");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rechercheExo;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
    @Override
    public String getExoProgrammeDescription(String recherche, int number) {
        String rechercheDescription = null;
        String sql = "SELECT *\n" +
                "FROM (\n" +
                "         SELECT exercice.description, ROW_NUMBER() OVER (ORDER BY exercice.id) AS RowNum\n" +
                "         FROM exercice,programme_exercice,programme WHERE programme.id = programme_exercice.programme_id " +
                "                AND programme_exercice.exercice_id = exercice.id AND programme_id = ?" +
                "     ) AS sub\n" +
                "WHERE RowNum = ?;";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setString(1, recherche);
                preparedStatement.setInt(2, number);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        rechercheDescription = result.getString("description");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rechercheDescription;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public String getExoProgrammeURL(int programme, int number) {
        String rechercheURL = null;
        String sql = "SELECT *\n" +
                "FROM (\n" +
                "         SELECT image_url, ROW_NUMBER() OVER (ORDER BY exercice.id) AS RowNum\n" +
                "         FROM exercice,programme_exercice,programme WHERE programme.id = programme_exercice.programme_id " +
                "                AND programme_exercice.exercice_id = exercice.id AND programme_id = ?" +
                "     ) AS sub\n" +
                "WHERE RowNum = ?;";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setInt(1, programme);
                preparedStatement.setInt(2, number);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        rechercheURL = result.getString("image_url");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rechercheURL;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public int getExoProgrammeNombre(int programme) {
        int rechercheNombre = 0;
        String sql = "SELECT COUNT(exercice.description) AS count FROM exercice,programme_exercice,programme WHERE programme.id = programme_exercice.programme_id " +
                "AND programme_exercice.exercice_id = exercice.id AND programme_id = ?";
        try {
            DataSource dataSource = DataSourceProvider.getDataSource();
            try (Connection cnx = dataSource.getConnection();
                 PreparedStatement preparedStatement = cnx.prepareStatement(sql)) {
                preparedStatement.setInt(1, programme);
                try (ResultSet result = preparedStatement.executeQuery()) {
                    if (result.next()) {
                        rechercheNombre = result.getInt("count");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rechercheNombre;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
