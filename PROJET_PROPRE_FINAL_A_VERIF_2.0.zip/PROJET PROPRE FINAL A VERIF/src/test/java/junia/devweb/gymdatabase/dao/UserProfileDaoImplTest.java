package junia.devweb.gymdatabase.dao;


import junia.devweb.gymdatabase.dao.impl.UserProfileProfileDaoImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class UserProfileDaoImplTest {

    @Mock
    private DataSource dataSource;

    @Mock
    private Connection connection;

    @Mock
    private PreparedStatement preparedStatement;

    @Mock
    private ResultSet resultSet;

    @InjectMocks
    private UserProfileDao userProfileDao;

    @BeforeEach
    void setUp() throws SQLException {
        MockitoAnnotations.openMocks(this);

        // Configuration des mocks
        when(dataSource.getConnection()).thenReturn(connection);
        when(connection.prepareStatement(anyString())).thenReturn(preparedStatement);
        when(preparedStatement.executeQuery()).thenReturn(resultSet);

        userProfileDao = new UserProfileProfileDaoImpl(dataSource);
    }

    @Test
    void testGetUserById() throws SQLException {
        // Configuration du résultat du ResultSet simulé
        when(resultSet.next()).thenReturn(true);
        when(resultSet.getInt("id")).thenReturn(1);
        when(resultSet.getString("nickname")).thenReturn("testUser");
        when(resultSet.getString("nom")).thenReturn("Test");
        when(resultSet.getString("prenom")).thenReturn("User");
        when(resultSet.getString("email")).thenReturn("test@example.com");
        when(resultSet.getString("mot_de_passe")).thenReturn("password123");
        when(resultSet.getString("date_inscription")).thenReturn("2023-01-01");
        when(resultSet.getString("role")).thenReturn("USER");

        Map<String, Object> user = userProfileDao.getUserById(1);

        // Vérifier que les méthodes du ResultSet ont été appelées correctement
        verify(preparedStatement).setInt(1, 1);
        verify(resultSet).next();
        verify(resultSet).getInt("id");
        verify(resultSet).getString("nickname");
        verify(resultSet).getString("nom");
        verify(resultSet).getString("prenom");
        verify(resultSet).getString("email");
        verify(resultSet).getString("mot_de_passe");
        verify(resultSet).getString("date_inscription");
        verify(resultSet).getString("role");

        // Vérifier le résultat
        assertEquals(1, user.get("id"));
        assertEquals("testUser", user.get("nickname"));
        assertEquals("Test", user.get("nom"));
        assertEquals("User", user.get("prenom"));
        assertEquals("test@example.com", user.get("email"));
        assertEquals("password123", user.get("mot_de_passe"));
        assertEquals("2023-01-01", user.get("date_inscription"));
        assertEquals("USER", user.get("role"));
    }
    @Test
    void testUpdatePassword() throws SQLException {
        String user = "testUser";
        String newPassword = "newPassword123";

        userProfileDao.updatePassword(user, newPassword);

        // Vérifier que les méthodes du PreparedStatement ont été appelées correctement
        verify(preparedStatement).setString(1, newPassword);
        verify(preparedStatement).setString(2, user);
        verify(preparedStatement).executeUpdate();
    }
}


