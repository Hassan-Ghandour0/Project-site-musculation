package junia.devweb.gymdatabase.servlets;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;

@WebServlet("/accueil")
public class AccueilServlet extends GenericServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JakartaServletWebApplication application = createApplication(req.getServletContext());
        IWebExchange webExchange = application.buildExchange(req , resp);
        WebContext context = new WebContext(webExchange);
        String User = (String) req.getAttribute("User");
        if(User != req.getSession().getAttribute("User")){
            User = (String) req.getSession().getAttribute("User");
        }
        ListeDao ListeDao = new ListeDaoImpl();
        if(ListeDao.VerifAdmin(User) == 1) {
            req.setAttribute("gestion","Gestion Users");
        }else{
            req.setAttribute("gestion","");
        }
        context.setVariable("User", User);
        TemplateEngine templateEngine = createTemplateEngine(application);
        templateEngine.process("index", context, resp.getWriter());
    }
}
