package junia.devweb.gymdatabase.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import junia.devweb.gymdatabase.dao.ConnexionDao;
import junia.devweb.gymdatabase.dao.InscriptionDao;
import junia.devweb.gymdatabase.dao.ListeDao;
import junia.devweb.gymdatabase.dao.impl.ConnexionDaoImpl;
import junia.devweb.gymdatabase.dao.impl.InscriptionDaoImpl;
import junia.devweb.gymdatabase.dao.impl.ListeDaoImpl;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import javax.xml.crypto.dom.DOMCryptoContext;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Objects;


@WebServlet("/liste")
public class ListeServlet extends GenericServlet {
    final ConnexionDao connexionDao = new ConnexionDaoImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        JakartaServletWebApplication application = createApplication(req.getServletContext());

        IWebExchange webExchange = application.buildExchange(req, resp);
        String User = (String) req.getSession().getAttribute("User");
        WebContext context = new WebContext(webExchange);
        context.setVariable("User", User);

        TemplateEngine templateEngine = createTemplateEngine(application);

        // Utiliser un StringWriter pour stocker le contenu généré par Thymeleaf
        StringWriter thymeleafOutput = new StringWriter();
        templateEngine.process("Liste", context, thymeleafOutput);

        // Ajouter le contenu généré par Thymeleaf au contenu manuel
        StringBuilder content = new StringBuilder(thymeleafOutput.toString());

        // Ajouter le reste du contenu généré manuellement
        final ListeDao ListeDao = new ListeDaoImpl();
        int nbExos = ListeDao.getMaxID();
        int i = 0;
        content.append("<main id = \"principal\">");
        for (i = 1; i <= ListeDao.getMaxID(); i++) {
            String nomExo = ListeDao.getNom(i);
            String descExo = ListeDao.getDescription(i);
            content.append("<flex>\n");
            if(i==1){content.append("   <img id = \"imgp1\" src=\"/img/imgExercices/").append(ListeDao.getImageURL(i)).append("\">\n");
                content.append("<flex id=\"Clairp\" class=\"case\">\n");}
            if(i % 2 == 0){content.append("   <img id = \"imgp\" src=\"/img/imgExercices/").append(ListeDao.getImageURL(i)).append("\">\n");
                content.append("<flex id=\"Sombre\" class=\"case\">\n");
            }
            if(i%2!=0 && i!=1){content.append("   <img id = \"imgp\" src=\"/img/imgExercices/").append(ListeDao.getImageURL(i)).append("\">\n");
                content.append("<flex id=\"Clair\" class=\"case\">\n");}
            content.append("        <div class=\"tableau\">\n");
            content.append("<h2>").append(nomExo).append(" </h2><hr/>\n");
            content.append("      <p>").append(descExo).append("</p>\n");
            content.append("    </div>\n");
            content.append("  </flex>");
            content.append("  </flex>");

        }

        if(ListeDao.VerifAdmin(User) == 1) {
            content.append("<p id=\"blocreation\"><form action=\"liste\" method=\"post\"><input type=\"text\" id=\"nomExo\" name=\"nomExo\" >><input type=\"text\" id=\"description\" name=\"description\" ><button type=\"submit\" id=\"addButton\" name=\"AddButon\">Ajouter</button></form></p>");
            req.setAttribute("gestion","Gestion Users");
        }else{
            req.setAttribute("gestion","");
        }

        content.append("</main>");
        content.append("</body>");
        content.append("</html>");


        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println(content.toString());
        out.close();
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        final ListeDao ListeDao = new ListeDaoImpl();
        String Recherche = req.getParameter("recherche");
        String AddNom = req.getParameter("nomExo");
        String AddDescription = req.getParameter("description");
        if(!Objects.equals(AddNom, "") && !Objects.equals(AddDescription, "")){
            ListeDao.addExercice(AddNom,AddDescription);
        }
        JakartaServletWebApplication application = createApplication(req.getServletContext());
        IWebExchange webExchange = application.buildExchange(req, resp);
        WebContext context = new WebContext(webExchange);

        TemplateEngine templateEngine = createTemplateEngine(application);
        StringWriter thymeleafOutput = new StringWriter();
        templateEngine.process("Liste", context, thymeleafOutput);

        // Ajouter le contenu généré par Thymeleaf au contenu manuel
        StringBuilder content = new StringBuilder(thymeleafOutput.toString());



        int i = 0;
        content.append("<main id = \"principal\">");
        for (i = 1; i <= ListeDao.getRechercheNombre(Recherche); i++) {
            String nomExo = ListeDao.getRechercheNom(Recherche,i);
            String descExo = ListeDao.getRechercheDescription(Recherche,i);
            content.append("<flex>\n");
            if(i==1){content.append("   <img id = \"imgp1\" src=\"/img/imgExercices/").append(ListeDao.getRechercheURL(Recherche,i)).append("\">\n");
                content.append("<flex id=\"Clairp\" class=\"case\">\n");}
            if(i % 2 == 0){content.append("   <img id = \"imgp\" src=\"/img/imgExercices/").append(ListeDao.getRechercheURL(Recherche,i)).append("\">\n");
                content.append("<flex id=\"Sombre\" class=\"case\">\n");
            }
            if(i%2!=0 && i!=1){content.append("   <img id = \"imgp\" src=\"/img/imgExercices/").append(ListeDao.getRechercheURL(Recherche,i)).append("\">\n");
                content.append("<flex id=\"Clair\" class=\"case\">\n");}
            content.append("        <div class=\"tableau\">\n");
            content.append("<h2>").append(nomExo).append(" </h2><hr/>\n");
            content.append("      <p>").append(descExo).append("</p>\n");
            content.append("    </div>\n");
            content.append("  </flex>");
            content.append("  </flex>");

        }


        content.append("</main>");
        content.append("</body>");
        content.append("</html>");


        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println(content.toString());
        out.close();
    }
}

