package junia.devweb.gymdatabase.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import junia.devweb.gymdatabase.dao.ConnexionDao;
import junia.devweb.gymdatabase.dao.impl.ConnexionDaoImpl;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

@WebServlet("/connexion")
public class ConnexionServlet extends GenericServlet {
    private static final Logger logger = LogManager.getLogger(ConnexionServlet.class);
    final ConnexionDao connexionDao = new ConnexionDaoImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        JakartaServletWebApplication application = createApplication(req.getServletContext());
        IWebExchange webExchange = application.buildExchange(req , resp);
        WebContext context = new WebContext(webExchange);

        TemplateEngine templateEngine = createTemplateEngine(application);
        templateEngine.process("connexion", context, resp.getWriter());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String User = req.getParameter("user");
        String MdpIn = req.getParameter("Mdp");
        String MdpCorrecte = connexionDao.getPassword(User);


        if (MdpIn.equals(MdpCorrecte)) {
            req.getSession().setAttribute("User", User);
            req.setAttribute("User", User);
            JakartaServletWebApplication application = createApplication(req.getServletContext());
            IWebExchange webExchange = application.buildExchange(req, resp);
            WebContext context = new WebContext(webExchange);

            TemplateEngine templateEngine = createTemplateEngine(application);
            templateEngine.process("index", context, resp.getWriter());

            logger.info("Connexion réussie pour l'utilisateur: {}", User);
        }else {
            String erreurMsg1 = "Nom d'utilisateur ou mot de passe incorrect";
            req.setAttribute("erreurMsg1", erreurMsg1);

            JakartaServletWebApplication application = createApplication(req.getServletContext());
            IWebExchange webExchange = application.buildExchange(req, resp);
            WebContext context = new WebContext(webExchange);

            TemplateEngine templateEngine = createTemplateEngine(application);
            templateEngine.process("connexion", context, resp.getWriter());

            logger.warn("Échec de connexion pour l'utilisateur: {}", User);
        }
    }
}
