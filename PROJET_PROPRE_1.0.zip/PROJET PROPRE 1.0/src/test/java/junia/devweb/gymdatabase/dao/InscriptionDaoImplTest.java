package junia.devweb.gymdatabase.dao;

import junia.devweb.gymdatabase.dao.impl.InscriptionDaoImpl;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class InscriptionDaoImplTest {

    @Test
    public void testInscription() {
        String dbUrl = "jdbc:mariadb://localhost:3306/gym_database";
        String dbUser = "clem";
        String dbPassword = "1234";

        InscriptionDao inscriptionDao = new InscriptionDaoImpl();

        // Remplacez les valeurs par celles que vous souhaitez tester
        String pseudo = "Test";
        String prenom = "Scarlett";
        String nom = "Johansson";
        String email = "a@b";
        String mdp = "password123";

        // Vérifier que le pseudo n'existe pas déjà
        assertFalse(((InscriptionDaoImpl) inscriptionDao).PseudoExiste(pseudo), "Le pseudo devrait ne pas exister après l'inscription.");

        // test pour la validation de l'email
        //assertTrue(((InscriptionDaoImpl) inscriptionDao).EmailValid(email), "L'email devrait être valide après l'inscription.");

        // Appel de la méthode Inscription avec les valeurs spécifiées
        boolean inscriptionValide = inscriptionDao.Inscription(pseudo, prenom, nom, email, mdp);

        // Vérifier si l'inscription est réussie
        assertTrue(inscriptionValide, "L'inscription devrait être réussie.");
    }
}
